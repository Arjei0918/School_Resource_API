using System.Text.Json.Serialization;

namespace PublicApiService.Models;

public sealed class PostDto
{
    [JsonPropertyName("userId")] public int UserId { get; set; }
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("body")] public string? Body { get; set; }
}
