# Public Posts API Service — C# School Activity

## API and instructor approval
Uses **JSONPlaceholder**, a documented public testing API.
- Docs: https://jsonplaceholder.typicode.com/guide/
- GET endpoint: https://jsonplaceholder.typicode.com/posts/1
- No API key or database needed.
- **Confirm your instructor approves this API before submitting.**

## Requirements
.NET SDK 10, internet for live requests, VS Code or a terminal.

## Run (PowerShell)
Open this folder and run:

```powershell
dotnet run -- 1
dotnet run -- 99999
dotnet run -- abc
dotnet run -- --test
```

`dotnet run -- 1` calls the live public API.
`dotnet run -- --test` runs six **offline mocked** scenarios.
Do not describe mocked responses as live API calls.

## Features
- HttpClient.GetAsync with async/await and cancellation token
- Typed PostDto deserialization with System.Text.Json
- Validate ID, user ID, title, and body before displaying
- Graceful HTTP 404, HTTP 500, invalid input, invalid DTO, malformed JSON
- Eight-second cancellation deadline and ten-second HttpClient timeout

## Test cases (expected, not yet executed on student's computer)
| Test | Expected |
|---|---|
| Mock success (200) | PASS |
| Mock unknown ID (404) | PASS |
| Mock HTTP 500 | PASS |
| Mock malformed JSON | PASS |
| Mock invalid DTO | PASS |
| Mock cancellation | PASS |

Also capture the live `dotnet run -- 1` success and optional live
`dotnet run -- 99999` error.

## Screenshots for Google Classroom
1. Run `dotnet run -- 1` and screenshot real successful post output.
2. Run `dotnet run -- --test` and screenshot six test results.
3. Put PNG files in `screenshots/`, then ZIP the folder.

## Three-sentence explanation
I built a C# console service that uses HttpClient and asynchronous methods to retrieve a post from the documented JSONPlaceholder API. The service deserializes the JSON response into a typed DTO and validates the post ID, user ID, title, and body before displaying the data. It also handles HTTP errors, malformed JSON, invalid data, and cancellation, with reproducible test cases for success and failure scenarios.
