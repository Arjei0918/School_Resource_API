using System.Net;
using System.Text.Json;
using PublicApiService.Models;

namespace PublicApiService.Services;

public sealed class PostService(HttpClient http)
{
    private static readonly JsonSerializerOptions Options = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public async Task<PostDto> GetPostAsync(int id, CancellationToken token = default)
    {
        if (id <= 0) throw new ArgumentException("Post ID must be positive.");

        using var response = await http.GetAsync(
            $"https://jsonplaceholder.typicode.com/posts/{id}", token);

        if (response.StatusCode == HttpStatusCode.NotFound)
            throw new PostNotFoundException($"Post {id} not found (HTTP 404).");

        if (!response.IsSuccessStatusCode)
            throw new HttpRequestException(
                $"API returned HTTP {(int)response.StatusCode} ({response.ReasonPhrase}).");

        await using var stream = await response.Content.ReadAsStreamAsync(token);
        PostDto? post;
        try
        {
            post = await JsonSerializer.DeserializeAsync<PostDto>(stream, Options, token);
        }
        catch (JsonException ex)
        {
            throw new InvalidDataException("Malformed JSON returned by API.", ex);
        }

        if (post is null || post.Id != id || post.UserId <= 0 ||
            string.IsNullOrWhiteSpace(post.Title) ||
            string.IsNullOrWhiteSpace(post.Body))
            throw new InvalidDataException("Missing or invalid post fields.");

        return post;
    }
}

public sealed class PostNotFoundException(string message) : Exception(message);
