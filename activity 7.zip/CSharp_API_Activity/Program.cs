using System.Net;
using System.Text;
using PublicApiService.Services;

Console.WriteLine("=== PUBLIC POSTS API SERVICE ===");
Console.WriteLine("API: https://jsonplaceholder.typicode.com");
Console.WriteLine();

if (args.Length > 0 && args[0] == "--test")
{
    await RunTestsAsync();
    return;
}

int id = 1;
if (args.Length > 0 && !int.TryParse(args[0], out id))
{
    Console.WriteLine("INPUT ERROR: Enter a numeric post ID.");
    return;
}

using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(10) };
using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(8));
try
{
    var post = await new PostService(client).GetPostAsync(id, cts.Token);
    Console.WriteLine("SUCCESS (HTTP 200)");
    Console.WriteLine($"Post ID: {post.Id}");
    Console.WriteLine($"User ID: {post.UserId}");
    Console.WriteLine($"Title: {post.Title}");
    Console.WriteLine($"Body: {post.Body}");
}
catch (ArgumentException ex) { Console.WriteLine("INPUT ERROR: " + ex.Message); }
catch (PostNotFoundException ex) { Console.WriteLine("NOT FOUND: " + ex.Message); }
catch (InvalidDataException ex) { Console.WriteLine("DATA ERROR: " + ex.Message); }
catch (OperationCanceledException) { Console.WriteLine("TIMEOUT/CANCELLED: Request cancelled or timed out."); }
catch (HttpRequestException ex) { Console.WriteLine("HTTP/NETWORK ERROR: " + ex.Message); }

static async Task RunTestsAsync()
{
    Console.WriteLine("=== AUTOMATED TESTS (MOCK HTTP RESPONSES) ===");
    const string valid = "{\"userId\":1,\"id\":1,\"title\":\"Sample title\",\"body\":\"Sample body\"}";
    var cases = new (string Name, HttpStatusCode Status, string Body, Type? ExpectedError)[]
    {
        ("Success 200", HttpStatusCode.OK, valid, null),
        ("Unknown ID 404", HttpStatusCode.NotFound, "{}", typeof(PostNotFoundException)),
        ("Server error 500", HttpStatusCode.InternalServerError, "{}", typeof(HttpRequestException)),
        ("Malformed JSON", HttpStatusCode.OK, "{invalid", typeof(InvalidDataException)),
        ("Invalid DTO fields", HttpStatusCode.OK,
            "{\"userId\":0,\"id\":1,\"title\":\"\",\"body\":null}", typeof(InvalidDataException))
    };
    int passed = 0;
    foreach (var test in cases)
    {
        using var client = new HttpClient(new FakeHandler(
            _ => new HttpResponseMessage(test.Status)
            { Content = new StringContent(test.Body, Encoding.UTF8, "application/json") }));
        try
        {
            var post = await new PostService(client).GetPostAsync(1);
            bool ok = test.ExpectedError is null && post.Id == 1;
            Console.WriteLine($"{(ok ? "PASS" : "FAIL")} | {test.Name}");
            if (ok) passed++;
        }
        catch (Exception ex)
        {
            bool ok = test.ExpectedError?.IsAssignableFrom(ex.GetType()) == true;
            Console.WriteLine($"{(ok ? "PASS" : "FAIL")} | {test.Name} | {ex.GetType().Name}");
            if (ok) passed++;
        }
    }

    using (var client = new HttpClient(new FakeHandler(
        _ => new HttpResponseMessage(HttpStatusCode.OK))))
    using (var cts = new CancellationTokenSource())
    {
        cts.Cancel();
        try
        {
            await new PostService(client).GetPostAsync(1, cts.Token);
            Console.WriteLine("FAIL | Cancellation");
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("PASS | Cancellation");
            passed++;
        }
    }
    Console.WriteLine($"TOTAL: {passed}/6 passed");
    if (passed != 6) Environment.ExitCode = 1;
}

sealed class FakeHandler(Func<HttpRequestMessage, HttpResponseMessage> respond)
    : HttpMessageHandler
{
    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult(respond(request));
    }
}
