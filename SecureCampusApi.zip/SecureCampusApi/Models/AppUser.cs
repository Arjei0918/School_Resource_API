using Microsoft.AspNetCore.Identity;

namespace SecureCampusApi.Models;

public class AppUser : IdentityUser
{
    public string FullName { get; set; } = string.Empty;
}