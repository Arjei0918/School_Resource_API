const express = require("express");
const swaggerUi = require("swagger-ui-express");

const app = express();
app.use(express.json());

const resources = [
  { id: 1, name: "Library", type: "Learning Resource" },
  { id: 2, name: "Computer Laboratory", type: "Facility" },
  { id: 3, name: "Online Learning Portal", type: "Digital Resource" }
];

app.get("/api/resources", (req, res) => {
  res.status(200).json(resources);
});

app.get("/api/resources/:id", (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isSafeInteger(id) || id <= 0) {
    return res.status(400).json({
      error: "Invalid resource ID"
    });
  }

  const resource = resources.find(r => r.id === id);

  if (!resource) {
    return res.status(404).json({
      error: "Resource not found"
    });
  }

  res.status(200).json(resource);
});

const swaggerDocument = {
  openapi: "3.0.0",
  info: {
    title: "School Resources API",
    version: "1.0.0",
    description: "School activity REST API"
  },
  paths: {
    "/api/resources": {
      get: {
        summary: "Get all resources",
        responses: {
          200: { description: "Resources retrieved successfully" }
        }
      }
    },
    "/api/resources/{id}": {
      get: {
        summary: "Get a resource by ID",
        parameters: [{
          name: "id",
          in: "path",
          required: true,
          schema: { type: "string" }
        }],
        responses: {
          200: { description: "Resource found" },
          400: { description: "Invalid resource ID" },
          404: { description: "Resource not found" }
        }
      }
    }
  }
};

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
  console.log("Swagger UI at http://localhost:3000/api-docs");
});
